# Referências 3D para Godot e Blender

São **25 arquivos GLB** em `objetos/`, com as formas, cores e medidas do jogo.
As placas estão **sem texto**, como solicitado. No jogo, o texto continua sendo
um Label3D separado e criado pelo código.

## Abrir no Blender

1. Use **Arquivo → Importar → glTF 2.0 (.glb/.gltf)**.
2. Escolha `objetos/mundo_completo.glb` para ver tudo, ou uma peça individual.
3. Para remodelar o prédio, use `objetos/biblioteca_completa.glb` como referência.

As peças continuam separadas dentro dos arquivos. O mundo completo inclui
terreno, pátio, prédio, interior, árvores, bancos, mesas, estantes, livros,
portas, luminárias e placas. Os livros agrupados no jogo viraram malhas
individuais nestas referências. São cópias visuais estáticas: mãos 2D, menus,
céu, scripts e interação continuam no projeto Godot.

## Observar e medir no Godot

Abra **`referencias/biblioteca.tscn`**, na aba 3D. Selecione uma peça na árvore
de nós e abra **Mesh → Size** no Inspector. **Transform → Position** mostra
sua posição. Essa cena é uma cópia para estudo; editá-la não altera o jogo.

As medidas adotam uma unidade por metro. Godot usa Y para altura; Blender usa Z
e converte os eixos ao importar. A estrutura principal tem 22 m nominais de
largura, 14 m de profundidade e paredes de 6,4 m. O topo do frontão fica a
8,47 m acima do chão. Beirais e detalhes aumentam a largura/profundidade totais;
a caixa envolvente da biblioteca também inclui a espessura do piso.

Peças pequenas têm origem na base e centro em X/Z. Prédio, interior e terreno
conservam a origem do mundo, para encaixar entre si.

## Dimensões das referências

Valores em metros, na ordem **X × Y × Z do Godot**, calculados a partir das malhas.
No Blender, a dimensão vertical é Z.

| Arquivo | Dimensões X × Y × Z (m) | Malhas |
| --- | --- | --- |
| [mundo_completo.glb](objetos/mundo_completo.glb) | 64 × 8.87 × 64 | 356 |
| [biblioteca_completa.glb](objetos/biblioteca_completa.glb) | 23.4 × 8.664 × 15.325 | 334 |
| [biblioteca_interior.glb](objetos/biblioteca_interior.glb) | 22 × 6.484 × 14 | 278 |
| [biblioteca_exterior.glb](objetos/biblioteca_exterior.glb) | 23.4 × 8.664 × 15.325 | 56 |
| [terreno_patio.glb](objetos/terreno_patio.glb) | 64 × 1.05 × 64 | 7 |
| [arvore_padrao.glb](objetos/arvore_padrao.glb) | 3.51 × 5.7 × 3.422 | 4 |
| [banco_externo.glb](objetos/banco_externo.glb) | 3.2 × 1.275 × 0.84 | 4 |
| [mesa_com_banquetas.glb](objetos/mesa_com_banquetas.glb) | 2.6 × 0.99 × 2.75 | 7 |
| [banqueta.glb](objetos/banqueta.glb) | 0.65 × 0.56 × 0.65 | 2 |
| [estante_com_livros.glb](objetos/estante_com_livros.glb) | 2.92 × 2.7 × 0.55 | 37 |
| [porta_entrada.glb](objetos/porta_entrada.glb) | 4.22 × 4.39 × 2.27 | 10 |
| [porta_sala.glb](objetos/porta_sala.glb) | 1.72 × 2.75 × 0.24 | 2 |
| [janela.glb](objetos/janela.glb) | 2 × 2.755 × 0.5 | 5 |
| [tapete.glb](objetos/tapete.glb) | 4.4 × 0.014 × 4.9 | 1 |
| [luminaria.glb](objetos/luminaria.glb) | 2 × 0.16 × 0.65 | 2 |
| [painel_questoes.glb](objetos/painel_questoes.glb) | 1.65 × 2.225 × 0.6 | 4 |
| [placa_sala.glb](objetos/placa_sala.glb) | 5.4 × 0.88 × 0.1 | 1 |
| [pilastra.glb](objetos/pilastra.glb) | 0.7 × 4.76 × 0.65 | 3 |
| [frontao.glb](objetos/frontao.glb) | 23.4 × 2.1 × 0.9 | 1 |
| [vaso.glb](objetos/vaso.glb) | 2.1 × 0.65 × 2.1 | 1 |
| [livro_1.glb](objetos/livro_1.glb) | 0.19 × 0.47 × 0.32 | 1 |
| [livro_2.glb](objetos/livro_2.glb) | 0.19 × 0.58 × 0.32 | 1 |
| [livro_3.glb](objetos/livro_3.glb) | 0.19 × 0.52 × 0.32 | 1 |
| [livro_4.glb](objetos/livro_4.glb) | 0.19 × 0.62 × 0.32 | 1 |
| [livro_5.glb](objetos/livro_5.glb) | 0.19 × 0.49 × 0.32 | 1 |

## Texto sobre uma placa feita no Blender

O GLB pode conter só a superfície e o suporte. No Godot, o código adiciona um
Label3D como filho e o coloca um pouco à frente da placa, evitando sobreposição.
O nome vem dos dados da sala: mudar o texto não exige editar o modelo no Blender.

## Geração

`ferramentas/gerar_referencias.gd` já foi executado. A ferramenta usa as funções
e medidas do jogo e grava cópias sem textos ou componentes de jogo. Ela precisa
do renderer gráfico Compatibility, sem `--headless`, para ler as instâncias
MultiMesh dos livros. Não é preciso executá-la manualmente nesta entrega.
A pasta `referencias/` é excluída da exportação do jogo para não aumentar o EXE.
